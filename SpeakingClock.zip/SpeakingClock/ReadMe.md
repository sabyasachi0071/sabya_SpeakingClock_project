Database used=H2 DB

Lombok used for annotation processing

validation is provided for the field 

Exception handling also Done 


implementation of Mid-Day and Night is done 




url =http://localhost:9090/api/v1/convert (Post Request )
paylods={"hours" : 12,
         "minutes" :51 
                    }

Test case of ServiceLayer is Completed .

I am getting conflict because of diff version of Swagger SO couldn't implement it .



