package com.SpeakingClock.ServiceImpl;

import com.SpeakingClock.Entity.TimeInput;
import com.SpeakingClock.Service.TimeConverter;
import org.springframework.stereotype.Service;

@Service
public class TimeConverterServiceImpl implements TimeConverter {

    @Override
    public String convertToWords(TimeInput timeInput) {


        int hours = timeInput.getHours();
        int minutes = timeInput.getMinutes();
        if ((hours == 12 && minutes == 0)) {
            return "Mid-Day";
        } else if (hours == 0 && minutes == 0) {
            return "Mid-Night";
        } else if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
            throw new IllegalArgumentException("Invalid time input");
        }
        String hoursInWords = convertHoursToWords(hours);
        String minutesInWords = convertMinutesToWords(minutes);

        return "It's " + hoursInWords + " " + minutesInWords;
    }

    private String convertHoursToWords(int hours) {

        if (hours == 0 || hours == 12) {
            return "twelve";
        } else if (hours < 13) {
            return convertLessThan13(hours);
        } else {
            return convertLessThan13(hours - 12);
        }
    }

    private String convertLessThan13(int hours) {
        switch(hours) {
            case 1: return "one";
            case 2: return "two";
            case 3: return "three";
            case 4: return "four";
            case 5: return "five";
            case 6: return "six";
            case 7: return "seven";
            case 8: return "eight";
            case 9: return "nine";
            case 10: return "ten";
            case 11: return "eleven";
            default: return "";
        }
    }

    private String convertMinutesToWords(int minutes) {
        if (minutes == 0) {
            return "o'clock";
        } else if (minutes < 10) {
            return "oh " + convertLessThan13(minutes);
        } else if (minutes < 20) {
            return "fifteen";
        } else {
            return convertTens(minutes);
        }
    }

    private String convertTens(int minutes) {
        int tens = minutes / 10;
        int ones = minutes % 10;

        switch(tens) {
            case 2: return "twenty " + convertLessThan13(ones);
            case 3: return "thirty " + convertLessThan13(ones);
            case 4: return "forty " + convertLessThan13(ones);
            case 5: return "fifty " + convertLessThan13(ones);
            default: return "";
        }
    }

}