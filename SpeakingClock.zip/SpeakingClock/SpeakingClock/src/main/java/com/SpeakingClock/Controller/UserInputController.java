package com.SpeakingClock.Controller;
import com.SpeakingClock.Entity.TimeInput;
import com.SpeakingClock.ServiceImpl.TimeConverterServiceImpl;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class UserInputController {
    @Autowired

    private TimeConverterServiceImpl timeConverterService;
    @PostMapping("/convert")
    public ResponseEntity<String> convertToWords(@RequestBody @Valid TimeInput timeInput) {

        String result = timeConverterService.convertToWords(timeInput);
        return ResponseEntity.ok(result);
    }
}
