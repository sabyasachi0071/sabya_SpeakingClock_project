package com.SpeakingClock.Service;

import com.SpeakingClock.Entity.TimeInput;

public interface TimeConverter {
    String convertToWords(TimeInput timeInput);

}
