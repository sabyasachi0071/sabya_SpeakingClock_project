package com.SpeakingClock.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import javax.management.ConstructorParameters;


@Entity
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@Data
public class TimeInput {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotNull
    @Min(value = 0, message = "Hours must be greater than or equal to 0")
    @Max(value = 23, message = "Hours must be less than or equal to 23")
    private int hours;

    @Min(value = 0, message = "Minutes must be greater than or equal to 0")
    @Max(value = 59, message = "Minutes must be less than or equal to 59")
    @NotNull
    private int minutes;

    public TimeInput(int hours, int minutes) {
        this.hours=hours;
        this.minutes=minutes;
    }
}
