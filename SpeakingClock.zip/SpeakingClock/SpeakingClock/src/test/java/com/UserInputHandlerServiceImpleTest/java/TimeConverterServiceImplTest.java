package com.UserInputHandlerServiceImpleTest.java;

import com.SpeakingClock.Entity.TimeInput;
import com.SpeakingClock.ServiceImpl.TimeConverterServiceImpl;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class TimeConverterServiceImplTest {

    private TimeConverterServiceImpl timeConverterService = new TimeConverterServiceImpl();

    @Test
    public void testConvertToWords_MidDay() {
        TimeInput timeInput = new TimeInput();
        timeInput.setHours(12);
        timeInput.setMinutes(0);
        assertEquals("Mid-Day", timeConverterService.convertToWords(timeInput));
    }

    @Test
    public void testConvertToWords_MidNight() {
        TimeInput timeInput = new TimeInput(0, 0);
        assertEquals("Mid-Night", timeConverterService.convertToWords(timeInput));
    }

    @Test
    public void testConvertToWords_ValidTime() {
        TimeInput timeInput = new TimeInput(15, 45);
        assertEquals("It's three forty five", timeConverterService.convertToWords(timeInput));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConvertToWords_InvalidHour() {
        TimeInput timeInput = new TimeInput(24, 30);
        timeConverterService.convertToWords(timeInput);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testConvertToWords_InvalidMinute() {
        TimeInput timeInput = new TimeInput(10, 60);
        timeConverterService.convertToWords(timeInput);
    }

    @Test
    public void testConvertToWords_EdgeCase() {
        TimeInput timeInput = new TimeInput(1, 1);
        assertEquals("It's one oh one", timeConverterService.convertToWords(timeInput));
    }

}
